Desafio Invnetione - Documentação
Giovana Thais G Carvalho
=============================================================================
Desafio referente a criação de formulário no qual é feito a inserção de dados do usuário como nome, idade ,sexo e data
obs: possuir um botão checkbox no qual ao ser selecionado é aberto uma caixa de texto para inserção de dados extras , assim como a contagem de até 10000 caracteres 
obs2: botão de apresentação de dados do usuário

Ferramentas utilizadas: 
  ide online plunker,
  HTML, CSS ,JS e Bootstrap5

Referencias utilizadas:
  https://www.w3schools.com/css/
  https://www.w3schools.com/html/
  https://www.w3schools.com/bootstrap/
  https://www.w3schools.com/js/
  https://www.w3schools.com/php/


Ajuda
============================================================================
Perguntas:
- Qual parte do código escrito deveria ser prioritariamente testada
 e por quê?



- Quais ferramentas poderiam ser utilizadas para testar a parte do código sugerida?



- Qual estratégia de teste você considera ideal para ser utilizada neste cenário?


